import React from "react";
import { BulletPoint } from "../types";
import { CheckCircle2, AlertCircle, ArrowRight, Sparkles } from "lucide-react";

interface Props {
  bullets: BulletPoint[];
}

const BulletPointAnalyzer: React.FC<Props> = ({ bullets }) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Sparkles className="text-amber-500" size={20} />
        <h2 className="text-xl font-bold text-zinc-900">Bullet Point Optimization</h2>
      </div>

      <div className="grid gap-4">
        {bullets.map((bullet, idx) => (
          <div key={idx} className="p-5 rounded-2xl border border-mild-border bg-mild-surface shadow-sm">
            <div className="flex items-start gap-3 mb-4">
              {bullet.strength === 'strong' ? (
                <CheckCircle2 className="text-emerald-500 mt-1 shrink-0" size={18} />
              ) : (
                <AlertCircle className="text-amber-500 mt-1 shrink-0" size={18} />
              )}
              <div>
                <p className="text-sm font-medium text-zinc-400 uppercase tracking-tight mb-1">Original</p>
                <p className="text-zinc-700 italic">"{bullet.original}"</p>
              </div>
            </div>

            <div className="pl-7 space-y-3">
              <div className="p-3 bg-mild-bg rounded-xl border border-mild-border">
                <p className="text-xs font-bold text-zinc-500 uppercase mb-2 flex items-center gap-2">
                  <ArrowRight size={12} /> Suggested Rewrite
                </p>
                <p className="text-zinc-900 font-medium">{bullet.rewritten}</p>
              </div>
              <p className="text-sm text-zinc-500">{bullet.feedback}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BulletPointAnalyzer;
