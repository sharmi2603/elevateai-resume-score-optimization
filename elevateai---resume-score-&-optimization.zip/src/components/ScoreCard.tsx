import React from "react";
import { motion } from "framer-motion";

interface ScoreCardProps {
  label: string;
  score: number;
  icon: React.ReactNode;
  color: string;
}

const ScoreCard: React.FC<ScoreCardProps> = ({ label, score, icon, color }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-mild-surface p-6 rounded-2xl border border-mild-border shadow-sm hover:shadow-md transition-shadow"
    >
      <div className="flex justify-between items-start mb-4">
        <div className={`p-2 rounded-xl bg-opacity-10 ${color}`}>
          {icon}
        </div>
        <span className="text-2xl font-bold text-zinc-900">{score}%</span>
      </div>
      <h3 className="text-sm font-medium text-zinc-500 uppercase tracking-wider">{label}</h3>
      <div className="mt-4 h-2 w-full bg-mild-bg rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${score}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
          className={`h-full rounded-full ${color.replace('text-', 'bg-')}`}
        />
      </div>
    </motion.div>
  );
};

export default ScoreCard;
