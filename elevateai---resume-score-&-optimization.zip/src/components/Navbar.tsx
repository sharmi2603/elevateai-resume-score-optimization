import React from "react";
import { auth, signInWithGoogle, logout } from "../firebase";
import { useAuthState } from "react-firebase-hooks/auth";
import { LogIn, LogOut, LayoutDashboard, FileText, Target } from "lucide-react";

const Navbar: React.FC = () => {
  const [user] = useAuthState(auth);

  return (
    <nav className="sticky top-0 z-50 bg-mild-surface/80 backdrop-blur-md border-b border-mild-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-mild-primary rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">E</span>
            </div>
            <span className="text-xl font-bold text-zinc-900 tracking-tight">ElevateAI</span>
          </div>

          <div className="flex items-center gap-4">
            {user ? (
              <>
                <div className="hidden md:flex items-center gap-6 mr-6">
                  <a href="#dashboard" className="text-sm font-medium text-zinc-600 hover:text-mild-primary transition-colors flex items-center gap-2">
                    <LayoutDashboard size={16} /> Dashboard
                  </a>
                  <a href="#analysis" className="text-sm font-medium text-zinc-600 hover:text-mild-primary transition-colors flex items-center gap-2">
                    <FileText size={16} /> Analysis
                  </a>
                </div>
                <div className="flex items-center gap-3 pl-6 border-l border-mild-border">
                  <img src={user.photoURL || ""} alt={user.displayName || ""} className="w-8 h-8 rounded-full border border-mild-border" />
                  <button
                    onClick={logout}
                    className="p-2 text-zinc-500 hover:text-mild-primary transition-colors"
                    title="Logout"
                  >
                    <LogOut size={20} />
                  </button>
                </div>
              </>
            ) : (
              <button
                onClick={signInWithGoogle}
                className="flex items-center gap-2 px-4 py-2 bg-mild-primary text-white rounded-xl text-sm font-medium hover:bg-mild-secondary transition-all shadow-sm"
              >
                <LogIn size={16} /> Sign In
              </button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
