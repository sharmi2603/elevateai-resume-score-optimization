import React from "react";
import { AlertTriangle, CheckCircle, Info } from "lucide-react";

interface Props {
  warnings: string[];
  missingSections: string[];
}

const ATSChecker: React.FC<Props> = ({ warnings, missingSections }) => {
  return (
    <div className="bg-mild-primary text-white p-8 rounded-3xl shadow-2xl overflow-hidden relative">
      <div className="absolute top-0 right-0 p-8 opacity-10">
        <Info size={120} />
      </div>
      
      <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
        <AlertTriangle className="text-mild-accent" /> ATS Compatibility Check
      </h2>

      <div className="grid md:grid-cols-2 gap-8 relative z-10">
        <div>
          <h3 className="text-sm font-bold text-mild-bg/60 uppercase tracking-widest mb-4">Critical Warnings</h3>
          <ul className="space-y-3">
            {warnings.length > 0 ? warnings.map((w, i) => (
              <li key={i} className="flex items-start gap-3 text-mild-bg/80 text-sm">
                <span className="w-1.5 h-1.5 rounded-full bg-mild-accent mt-1.5 shrink-0" />
                {w}
              </li>
            )) : (
              <li className="flex items-center gap-2 text-emerald-300 text-sm">
                <CheckCircle size={16} /> No critical ATS issues detected.
              </li>
            )}
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-bold text-mild-bg/60 uppercase tracking-widest mb-4">Missing Sections</h3>
          <div className="flex flex-wrap gap-2">
            {missingSections.length > 0 ? missingSections.map((s, i) => (
              <span key={i} className="px-3 py-1 bg-white/10 rounded-full text-xs font-medium text-white border border-white/10">
                {s}
              </span>
            )) : (
              <p className="text-emerald-300 text-sm flex items-center gap-2">
                <CheckCircle size={16} /> All essential sections found.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ATSChecker;
