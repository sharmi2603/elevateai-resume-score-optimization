import React from "react";
import { JobMatch } from "../types";
import { Target, XCircle, Lightbulb } from "lucide-react";

interface Props {
  match: JobMatch;
}

const JobMatchPanel: React.FC<Props> = ({ match }) => {
  return (
    <div className="bg-mild-surface p-8 rounded-3xl border border-mild-border shadow-sm">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-mild-bg text-mild-primary rounded-2xl">
            <Target size={24} />
          </div>
          <div>
            <h2 className="text-xl font-bold text-zinc-900">Job Description Match</h2>
            <p className="text-sm text-zinc-500">How well you align with the target role</p>
          </div>
        </div>
        <div className="text-right">
          <span className="text-4xl font-black text-zinc-900">{match.matchPercentage}%</span>
          <p className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Match Score</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-zinc-900 uppercase flex items-center gap-2">
            <XCircle className="text-rose-500" size={16} /> Missing Skills & Keywords
          </h3>
          <div className="flex flex-wrap gap-2">
            {match.missingSkills.map((skill, i) => (
              <span key={i} className="px-3 py-1 bg-rose-50 text-rose-600 rounded-lg text-xs font-medium border border-rose-100">
                {skill}
              </span>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-sm font-bold text-zinc-900 uppercase flex items-center gap-2">
            <Lightbulb className="text-mild-accent" size={16} /> Alignment Strategy
          </h3>
          <p className="text-sm text-zinc-600 leading-relaxed">
            {match.alignmentFeedback}
          </p>
        </div>
      </div>
    </div>
  );
};

export default JobMatchPanel;
