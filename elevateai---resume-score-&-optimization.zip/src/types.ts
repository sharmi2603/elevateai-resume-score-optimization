export interface CategoryScores {
  ats: number;
  impact: number;
  brevity: number;
  style: number;
  structure: number;
  keywords: number;
}

export interface BulletPoint {
  original: string;
  rewritten: string;
  strength: 'weak' | 'average' | 'strong';
  feedback: string;
}

export interface ResumeAnalysis {
  summary: string;
  strengths: string[];
  weaknesses: string[];
  missingSections: string[];
  atsWarnings: string[];
}

export interface JobMatch {
  matchPercentage: number;
  missingSkills: string[];
  alignmentFeedback: string;
}

export interface ResumeReport {
  id?: string;
  userId: string;
  fileName: string;
  overallScore: number;
  categoryScores: CategoryScores;
  analysis: ResumeAnalysis;
  bullets: BulletPoint[];
  keywords: {
    present: string[];
    missing: string[];
  };
  jobMatch: JobMatch;
  createdAt: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  createdAt: string;
}
