import React, { useState, useEffect } from "react";
import { auth, db, signInWithGoogle } from "./firebase";
import { useAuthState } from "react-firebase-hooks/auth";
import { collection, addDoc, query, where, orderBy, onSnapshot } from "firebase/firestore";
import { Upload, FileText, CheckCircle, AlertCircle, Loader2, Sparkles, Trophy, Target, BarChart3, ChevronRight } from "lucide-react";
import Navbar from "./components/Navbar";
import ScoreCard from "./components/ScoreCard";
import BulletPointAnalyzer from "./components/BulletPointAnalyzer";
import ATSChecker from "./components/ATSChecker";
import JobMatchPanel from "./components/JobMatchPanel";
import ErrorBoundary from "./components/ErrorBoundary";
import { ResumeReport } from "./types";
import { motion, AnimatePresence } from "framer-motion";
import { GoogleGenAI } from "@google/genai";

const App: React.FC = () => {
  const [user, loading] = useAuthState(auth);
  const [file, setFile] = useState<File | null>(null);
  const [jobTitle, setJobTitle] = useState("");
  const [jobDescription, setJobDescription] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [report, setReport] = useState<ResumeReport | null>(null);
  const [history, setHistory] = useState<ResumeReport[]>([]);

  useEffect(() => {
    if (user) {
      const q = query(
        collection(db, "users", user.uid, "reports"),
        orderBy("createdAt", "desc")
      );
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const reports = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ResumeReport));
        setHistory(reports);
      });
      return unsubscribe;
    }
  }, [user]);

  const handleUpload = async () => {
    console.log("handleUpload triggered");
    if (!file) {
      console.log("No file selected");
      return;
    }
    if (!user) {
      console.log("No user authenticated");
      return;
    }
    
    setAnalyzing(true);
    setReport(null);

    const formData = new FormData();
    formData.append("resume", file);

    try {
      console.log("Calling /api/extract-text...");
      // 1. Extract text from resume using backend
      const extractResponse = await fetch("/api/extract-text", {
        method: "POST",
        body: formData,
      });

      if (!extractResponse.ok) {
        const errorData = await extractResponse.json();
        throw new Error(errorData.error || "Failed to extract text from resume");
      }
      
      const { text: resumeText } = await extractResponse.json();
      console.log("Text extracted successfully, length:", resumeText.length);

      // 2. Analyze resume using Gemini on the frontend
      console.log("Initializing Gemini AI...");
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error("Gemini API Key is missing. Please check your environment variables.");
      }
      
      const ai = new GoogleGenAI({ apiKey });
      const prompt = `
        You are an expert recruiter and ATS optimization specialist. 
        Analyze the following resume text and provide a detailed report in JSON format.
        
        Resume Text:
        ${resumeText}
        
        ${jobDescription ? `Target Job Description:\n${jobDescription}` : ""}
        ${jobTitle ? `Target Job Title: ${jobTitle}` : ""}

        The response MUST be a valid JSON object with the following structure:
        {
          "overallScore": number (0-100),
          "categoryScores": {
            "ats": number,
            "impact": number,
            "brevity": number,
            "style": number,
            "structure": number,
            "keywords": number
          },
          "analysis": {
            "summary": "string",
            "strengths": ["string"],
            "weaknesses": ["string"],
            "missingSections": ["string"],
            "atsWarnings": ["string"]
          },
          "bullets": [
            {
              "original": "string",
              "rewritten": "string",
              "strength": "weak" | "average" | "strong",
              "feedback": "string"
            }
          ],
          "keywords": {
            "present": ["string"],
            "missing": ["string"]
          },
          "jobMatch": {
            "matchPercentage": number,
            "missingSkills": ["string"],
            "alignmentFeedback": "string"
          }
        }
        
        Focus on:
        - Action verbs and measurable metrics.
        - ATS-friendly structure.
        - Keyword density.
        - Brevity and impact.
        
        Return ONLY the JSON.
      `;

      console.log("Generating content with Gemini...");
      const aiResponse = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });

      const responseText = aiResponse.text;
      console.log("AI Response received");
      if (!responseText) throw new Error("AI failed to generate a response");

      // Clean up JSON response if model wraps it in markdown blocks
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      const analysisData = jsonMatch ? JSON.parse(jsonMatch[0]) : JSON.parse(responseText);

      const newReport: ResumeReport = {
        ...analysisData,
        userId: user.uid,
        fileName: file.name,
        createdAt: new Date().toISOString(),
      };

      // 3. Save to Firestore
      console.log("Saving report to Firestore...");
      await addDoc(collection(db, "users", user.uid, "reports"), newReport);
      setReport(newReport);
      console.log("Analysis complete!");
    } catch (error: any) {
      console.error("Analysis error:", error);
      alert(`Failed to analyze resume: ${error.message || "Unknown error"}`);
    } finally {
      setAnalyzing(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-mild-bg">
      <Loader2 className="animate-spin text-mild-secondary" size={40} />
    </div>
  );

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-mild-bg font-sans text-zinc-800">
        <Navbar />

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {!user ? (
            <div className="text-center py-20">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-3xl mx-auto"
              >
                <h1 className="text-6xl font-black tracking-tighter mb-6 bg-gradient-to-br from-mild-primary to-mild-secondary bg-clip-text text-transparent">
                  Get Hired Faster with AI-Powered Insights.
                </h1>
                <p className="text-xl text-zinc-600 mb-10 leading-relaxed">
                  ElevateAI scores your resume, fixes your bullet points, and checks your ATS compatibility in seconds.
                </p>
                <button
                  onClick={signInWithGoogle}
                  className="px-8 py-4 bg-mild-primary text-white rounded-2xl font-bold text-lg hover:bg-mild-secondary transition-all shadow-xl hover:shadow-2xl hover:-translate-y-1"
                >
                  Start Scoring for Free
                </button>
              </motion.div>
              
              <div className="mt-24 grid md:grid-cols-3 gap-8 text-left">
                {[
                  { icon: <Trophy className="text-amber-500" />, title: "Recruiter-Grade Scoring", desc: "Get an instant score based on clarity, impact, and brevity." },
                  { icon: <Sparkles className="text-indigo-500" />, title: "Smart Rewrites", desc: "AI-powered bullet point optimization with measurable metrics." },
                  { icon: <Target className="text-emerald-500" />, title: "JD Matching", desc: "See exactly how you stack up against specific job descriptions." }
                ].map((feature, i) => (
                  <div key={i} className="bg-mild-surface p-8 rounded-3xl border border-mild-border shadow-sm">
                    <div className="mb-4">{feature.icon}</div>
                    <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
                    <p className="text-zinc-500 text-sm leading-relaxed">{feature.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-12">
              {/* Upload Section */}
              <section className="bg-mild-surface p-10 rounded-[2.5rem] border border-mild-border shadow-sm">
                <div className="max-w-2xl mx-auto text-center">
                  <h2 className="text-3xl font-bold mb-2">Analyze Your Resume</h2>
                  <p className="text-zinc-500 mb-8">Upload your PDF or DOCX to get started</p>
                  
                  <div className="space-y-6">
                    <div className="relative group">
                      <input
                        type="file"
                        onChange={(e) => setFile(e.target.files?.[0] || null)}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                        accept=".pdf,.docx"
                      />
                      <div className={`p-12 border-2 border-dashed rounded-3xl transition-all ${file ? 'border-mild-primary bg-mild-bg' : 'border-mild-border group-hover:border-mild-secondary bg-mild-bg'}`}>
                        <Upload className={`mx-auto mb-4 ${file ? 'text-mild-primary' : 'text-mild-secondary'}`} size={48} />
                        <p className="font-medium text-zinc-900">{file ? file.name : 'Drop your resume here or click to browse'}</p>
                        <p className="text-xs text-zinc-400 mt-2">PDF or DOCX up to 5MB</p>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <input
                        type="text"
                        placeholder="Target Job Title (Optional)"
                        value={jobTitle}
                        onChange={(e) => setJobTitle(e.target.value)}
                        className="px-5 py-4 bg-mild-bg border border-mild-border rounded-2xl focus:ring-2 focus:ring-mild-primary outline-none transition-all"
                      />
                      <textarea
                        placeholder="Paste Job Description (Optional)"
                        value={jobDescription}
                        onChange={(e) => setJobDescription(e.target.value)}
                        className="px-5 py-4 bg-mild-bg border border-mild-border rounded-2xl focus:ring-2 focus:ring-mild-primary outline-none transition-all h-14 resize-none"
                      />
                    </div>

                    <button
                      onClick={handleUpload}
                      disabled={!file || analyzing}
                      className="w-full py-5 bg-mild-primary text-white rounded-2xl font-bold text-lg hover:bg-mild-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-3 shadow-lg"
                    >
                      {analyzing ? (
                        <>
                          <Loader2 className="animate-spin" size={24} /> Analyzing with AI...
                        </>
                      ) : (
                        <>
                          <Sparkles size={24} /> Get My Score
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </section>

              {/* Results Section */}
              <AnimatePresence>
                {report && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="space-y-12"
                    id="analysis"
                  >
                    {/* Score Overview */}
                    <div className="grid md:grid-cols-4 gap-6">
                      <div className="md:col-span-2 bg-mild-primary text-white p-10 rounded-[2.5rem] flex flex-col justify-center relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-10 opacity-10">
                          <BarChart3 size={160} />
                        </div>
                        <h3 className="text-mild-bg/60 font-bold uppercase tracking-widest text-sm mb-2">Overall Resume Score</h3>
                        <div className="flex items-baseline gap-4">
                          <span className="text-8xl font-black">{report.overallScore}</span>
                          <span className="text-2xl text-mild-bg/40">/ 100</span>
                        </div>
                        <p className="mt-6 text-mild-bg/80 leading-relaxed max-w-md">
                          {report.analysis.summary}
                        </p>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 md:col-span-2">
                        <ScoreCard label="ATS Ready" score={report.categoryScores.ats} icon={<FileText />} color="text-indigo-600" />
                        <ScoreCard label="Impact" score={report.categoryScores.impact} icon={<Trophy />} color="text-amber-600" />
                        <ScoreCard label="Brevity" score={report.categoryScores.brevity} icon={<Sparkles />} color="text-emerald-600" />
                        <ScoreCard label="Keywords" score={report.categoryScores.keywords} icon={<Target />} color="text-rose-600" />
                      </div>
                    </div>

                    {/* ATS & Job Match */}
                    <ATSChecker warnings={report.analysis.atsWarnings} missingSections={report.analysis.missingSections} />
                    {report.jobMatch.matchPercentage > 0 && <JobMatchPanel match={report.jobMatch} />}

                    {/* Bullet Points */}
                    <BulletPointAnalyzer bullets={report.bullets} />

                    {/* Strengths & Weaknesses */}
                    <div className="grid md:grid-cols-2 gap-8">
                      <div className="bg-emerald-50/50 p-8 rounded-3xl border border-emerald-100">
                        <h3 className="text-lg font-bold text-emerald-900 mb-4 flex items-center gap-2">
                          <CheckCircle className="text-emerald-500" /> Key Strengths
                        </h3>
                        <ul className="space-y-3">
                          {report.analysis.strengths.map((s, i) => (
                            <li key={i} className="text-emerald-800 text-sm flex items-start gap-2">
                              <span className="mt-1.5 w-1 h-1 rounded-full bg-emerald-400 shrink-0" /> {s}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="bg-rose-50/50 p-8 rounded-3xl border border-rose-100">
                        <h3 className="text-lg font-bold text-rose-900 mb-4 flex items-center gap-2">
                          <AlertCircle className="text-rose-500" /> Areas for Improvement
                        </h3>
                        <ul className="space-y-3">
                          {report.analysis.weaknesses.map((w, i) => (
                            <li key={i} className="text-rose-800 text-sm flex items-start gap-2">
                              <span className="mt-1.5 w-1 h-1 rounded-full bg-rose-400 shrink-0" /> {w}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* History Section */}
              {history.length > 0 && (
                <section id="dashboard" className="pt-12 border-t border-mild-border">
                  <h2 className="text-2xl font-bold mb-8">Recent Reports</h2>
                  <div className="grid md:grid-cols-3 gap-6">
                    {history.map((h) => (
                      <button
                        key={h.id}
                        onClick={() => setReport(h)}
                        className="bg-mild-surface p-6 rounded-2xl border border-mild-border shadow-sm hover:shadow-md transition-all text-left group"
                      >
                        <div className="flex justify-between items-start mb-4">
                          <div className="p-2 bg-mild-bg rounded-lg group-hover:bg-mild-primary group-hover:text-white transition-colors">
                            <FileText size={20} />
                          </div>
                          <span className="text-xl font-bold text-zinc-900">{h.overallScore}</span>
                        </div>
                        <h4 className="font-bold text-zinc-900 truncate">{h.fileName}</h4>
                        <p className="text-xs text-zinc-400 mt-1">{new Date(h.createdAt).toLocaleDateString()}</p>
                        <div className="mt-4 flex items-center text-xs font-bold text-zinc-400 group-hover:text-mild-primary transition-colors">
                          VIEW REPORT <ChevronRight size={14} />
                        </div>
                      </button>
                    ))}
                  </div>
                </section>
              )}
            </div>
          )}
        </main>

        <footer className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 border-t border-mild-border mt-20">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-mild-primary rounded flex items-center justify-center">
                <span className="text-white font-bold text-xs">E</span>
              </div>
              <span className="font-bold text-zinc-900">ElevateAI</span>
            </div>
            <p className="text-sm text-zinc-400">© 2026 ElevateAI. Privacy-first resume optimization.</p>
            <div className="flex gap-6">
              <a href="#" className="text-sm text-zinc-400 hover:text-mild-primary">Privacy</a>
              <a href="#" className="text-sm text-zinc-400 hover:text-mild-primary">Terms</a>
              <a href="#" className="text-sm text-zinc-400 hover:text-mild-primary">Support</a>
            </div>
          </div>
        </footer>
      </div>
    </ErrorBoundary>
  );
};

export default App;
